node_modules
data/
.env
*.log
