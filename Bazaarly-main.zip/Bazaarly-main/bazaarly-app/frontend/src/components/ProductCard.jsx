import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import StarRating from './StarRating';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { Api } from '../api/client';
import MerchantBadge from './MerchantBadge';

// Reusable premium product card — used across listing pages, related
// products, "trending" sections etc. Shows: image, name, brand, price,
// original price, discount, merchant, a "Dostivox Recommended" badge when
// the admin has flagged the product, a last-updated date, and a
// Check Price / View Deal CTA. For affiliate products it also carries a
// short affiliate disclosure near the CTA — never hidden, never omitted.
export default function ProductCard({ product }) {
  const { addToCart } = useCart();
  const { user } = useAuth();
  const [busy, setBusy] = useState(false);
  const [wished, setWished] = useState(false);
  const isAffiliate = product.productType === 'affiliate';

  // A product can have multiple merchant offers (Amazon, Flipkart, etc.) —
  // show the cheapest one on the card. Falls back to the legacy flat fields
  // for products saved before multi-offer support existed.
  const offers = product.offers?.length ? product.offers : (isAffiliate ? [{
    merchant: product.merchant, merchantLogo: product.merchantLogo,
    currentPrice: product.currentPrice, originalPrice: product.originalPrice,
    discountPercentage: product.discountPercentage, affiliateUrl: product.affiliateUrl, ctaText: product.ctaText,
  }] : []);
  const bestOffer = isAffiliate
    ? offers.reduce((best, o) => (!best || (o.currentPrice ?? Infinity) < (best.currentPrice ?? Infinity) ? o : best), null)
    : null;

  const displayPrice = isAffiliate ? bestOffer?.currentPrice : product.price;
  const displayOriginal = isAffiliate ? bestOffer?.originalPrice : product.mrp;
  const discount = isAffiliate
    ? (bestOffer?.discountPercentage || (displayOriginal ? Math.round(((displayOriginal - displayPrice) / displayOriginal) * 100) : 0))
    : Math.round(((product.mrp - product.price) / product.mrp) * 100);

  // Last updated — for affiliate deals this is when the price was last
  // checked; for own products, when the listing itself was last edited.
  const lastUpdatedRaw = isAffiliate ? (product.lastChecked || product.updatedAt) : product.updatedAt;
  const lastUpdated = lastUpdatedRaw
    ? new Date(lastUpdatedRaw).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })
    : null;

  const handleAdd = async (e) => {
    e.preventDefault();
    if (!user) return (window.location.href = '/login');
    setBusy(true);
    try { await addToCart(product.id, 1); } finally { setBusy(false); }
  };

  const handleCheckDeal = (e) => {
    e.preventDefault();
    if (bestOffer?.affiliateUrl) window.open(bestOffer.affiliateUrl, '_blank', 'noopener,noreferrer');
  };

  const handleWishlist = async (e) => {
    e.preventDefault();
    if (!user) return (window.location.href = '/login');
    setWished((w) => !w);
    try { wished ? await Api.removeWishlist(product.id) : await Api.addWishlist(product.id); } catch {}
  };

  return (
    <Link to={`/products/${product.slug}`} className="card group relative overflow-hidden animate-fadeUp">
      <div className="relative aspect-square overflow-hidden rounded-t-xl2 bg-slate-100">
        <img
          src={product.thumbnail || product.images?.[0]}
          alt={product.title}
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
          loading="lazy"
        />
        {discount > 0 && (
          <span className="absolute top-3 left-3 rounded-full bg-accent-500 px-2.5 py-1 text-xs font-bold text-white shadow">
            -{discount}%
          </span>
        )}
        {isAffiliate && (
          <span className="absolute top-3 right-12 rounded-full bg-purple-500 px-2.5 py-1 text-xs font-bold text-white shadow">
            Deal
          </span>
        )}
        <button
          onClick={handleWishlist}
          className="absolute top-3 right-3 grid h-9 w-9 place-items-center rounded-full bg-white/90 shadow hover:scale-110 transition"
          aria-label="Add to wishlist"
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill={wished ? '#ff6b35' : 'none'} stroke={wished ? '#ff6b35' : '#64748b'} strokeWidth="2">
            <path d="M12 21s-7.5-4.6-10-9.1C.6 8.4 2 4.5 5.6 3.7 8 3.2 10 4.3 12 6.8c2-2.5 4-3.6 6.4-3.1 3.6.8 5 4.7 3.6 8.2C19.5 16.4 12 21 12 21z" />
          </svg>
        </button>
        <div className="absolute inset-x-0 bottom-0 translate-y-full bg-white/95 backdrop-blur px-3 py-2 transition-transform duration-300 group-hover:translate-y-0">
          {isAffiliate ? (
            <button onClick={handleCheckDeal} className="btn-primary w-full text-sm py-2">
              {bestOffer?.ctaText || 'View Deal'}
            </button>
          ) : (
            <button onClick={handleAdd} disabled={busy} className="btn-primary w-full text-sm py-2">
              {busy ? 'Adding…' : 'Add to Cart'}
            </button>
          )}
        </div>
      </div>
      <div className="p-4">
        <div className="flex items-center justify-between gap-2">
          <p className="text-xs font-semibold uppercase tracking-wide text-brand-500">{product.brand}</p>
          {isAffiliate && bestOffer?.merchant && <MerchantBadge merchant={bestOffer.merchant} logo={bestOffer.merchantLogo} />}
        </div>

        {product.isRecommended && (
          <span className="mt-1.5 inline-flex items-center gap-1 rounded-full bg-amber-100 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-amber-700">
            ★ Dostivox Recommended
          </span>
        )}

        <h3 className="mt-1 line-clamp-2 font-medium text-slate-800">{product.title}</h3>
        {!isAffiliate && (
          <div className="mt-1.5"><StarRating value={product.rating} count={product.rating_count} showValue size={14} /></div>
        )}
        <div className="mt-2 flex items-baseline gap-2">
          <span className="text-lg font-bold text-slate-900">₹{displayPrice?.toLocaleString()}</span>
          {displayOriginal > displayPrice && (
            <span className="text-sm text-slate-400 line-through">₹{displayOriginal?.toLocaleString()}</span>
          )}
        </div>

        {isAffiliate && (
          <>
            <p className="mt-1 text-[11px] text-slate-400">
              {offers.length > 1 ? `Lowest of ${offers.length} stores` : 'Affiliate link'}
              {lastUpdated && ` · Updated ${lastUpdated}`}
            </p>
            {/* Required affiliate disclosure — kept plainly visible, not hidden behind hover. */}
            <p className="mt-1.5 text-[10px] leading-snug text-slate-400">
              Affiliate link — we may earn a commission if you purchase through our link.
            </p>
          </>
        )}
        {!isAffiliate && lastUpdated && (
          <p className="mt-1 text-[11px] text-slate-400">Updated {lastUpdated}</p>
        )}
      </div>
    </Link>
  );
}
